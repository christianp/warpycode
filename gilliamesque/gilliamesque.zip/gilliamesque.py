import sys, pygame, os, math
pygame.init()
files=filter(lambda x: x[-4:]=='.txt' and 1, os.listdir(''))
for a in ['%i %s' % (i,files[i]) for i in range(len(files))]: print a
scenefile=raw_input("Pick a number> ")
if scenefile.isdigit(): scenefile=files[int(scenefile)]
else: scenefile=raw_input("Scene file> ")
if scenefile=='': scenefile='save.txt'

size = width, height = 1024,768
black = 0, 0, 0
white=255,255,255
 
screen = pygame.display.set_mode(size)

bits=[]

class bit:
	def __init__(self,imagename,image,pos,rot):
		self.imagename=imagename
		self.image=image
		self.surfarray=pygame.surfarray.array_alpha(self.image)
		self.imagerect=self.image.get_rect()
		self.width,self.height=self.image.get_size()
		self.pos=[]
		self.rot=rot
		if self.rot:
			self.offset=(int(pos[6:9]),int(pos[9:12]))
			self.handle=(int(pos[:3])-self.imagerect.center[0],int(pos[3:6])-self.imagerect.center[1])
			self.handledist=math.hypot(self.handle[0],self.handle[1])
			self.handletheta=math.atan2(self.handle[1],self.handle[0])
			self.centre=self.imagerect.center
			self.rotpos=self.offset
			self.oldframe=0
			pos=pos[12:]
			while len(pos):
				theta=int(pos[:3])
				pos=pos[3:]
				self.pos.append(theta)
		else:
			while len(pos):
				x=int(pos[:3])
				y=int(pos[3:6])
				pos=pos[6:]
				self.pos.append((x,y))
			self.oldpos=(0,0)
			
		bits.append(self)
	def getpos(self,frame):
		if self.rot: return self.rotpos
		if frame>=len(self.pos): frame=len(self.pos)-1
		return self.pos[frame]
	def getrot(self,frame):
		if not self.rot: return 0
		if frame>=len(self.pos): frame=len(self.pos)-1
		return self.pos[frame]
	def checksurfarray(self,x,y):
		print x,y
		if x>=self.width or x<0 or y>=self.height or y<0: return 0
		if self.surfarray[x][y]!=0: return self.surfarray[x][y]
		return 0
	def draw(self,frame):
		if frame>=len(self.pos): frame=len(self.pos)-1
		if self.rot:
			pos=self.getrot(frame)
			image=pygame.transform.rotate(self.image,pos)
			rect=image.get_rect()
			x,y=rect.center[0]-self.centre[0],rect.center[1]-self.centre[1]
			offx,offy=self.handledist*math.cos(pos*math.pi/180+self.handletheta)-self.handle[0],self.handledist*math.sin(pos*math.pi/180+self.handletheta)-self.handle[1]
			posx=self.offset[0]+offx-x
			posy=self.offset[1]-offy-y
			self.rotpos=(int(posx),int(posy))
			screen.blit(image,rect.move(self.rotpos))
			self.rotrect=rect.move(self.rotpos)
			if frame!=self.oldframe:
				self.surfarray=pygame.surfarray.array_alpha(image)
				self.oldframe=frame
		else:
			pos=self.getpos(frame)
			rect=self.imagerect
			image=self.image
			rect.move_ip(pos[0]-self.oldpos[0],pos[1]-self.oldpos[1])
			self.oldpos=pos
			screen.blit(self.image,self.imagerect)
		
def loadscene(filename):
	lines=map(lambda x: x.strip(),open(filename).readlines())
	while len(lines):
		imagename, pos, rot = lines[:3]
		lines=lines[3:]
		image=pygame.image.load(imagename)
		rot=int(rot)
		print imagename
		bit(imagename,image,pos,rot)
 
def savescene(filename):
	f=open(filename,'w')
	def pad(x,length):
		return '0'*(length-len(x))+x
		
	for bit in bits:
		f.write(bit.imagename+'\n')
		outpos=''
		if bit.rot:
			outpos+=pad(str(bit.handle[0]+bit.imagerect.center[0]),3)+pad(str(bit.handle[1]+bit.imagerect.center[1]),3)
			outpos+=pad(str(bit.offset[0]),3)+pad(str(bit.offset[1]),3)
		for pos in bit.pos:
			if bit.rot:
				rot=pad(str(pos),3)
				outpos+=rot
			else:
				x,y=map(str,pos)
				x=pad(x,3)
				y=pad(y,3)
				outpos+=x+y
		f.write(outpos+'\n')
		f.write('%i\n' % bit.rot)
	f.close()

loadscene(scenefile)
frame=0
mousedown=0
playmode=0
keydown=0
shotstaken=0
selectedbit=None
getbiggest=lambda x:reduce(lambda a,b:a>b and a or b,x)
while 1:
	mx,my=pygame.mouse.get_pos()

	for event in pygame.event.get():
		if event.type == pygame.QUIT: sys.exit()
		elif event.type == pygame.MOUSEBUTTONDOWN:
			pos=px,py=event.pos
			for bit in bits:
				bx,by=bit.getpos(frame)
				if bit.checksurfarray(px-bx,py-by) and mousedown==0:
					selectedbit=bit
					mousedown=1
					if playmode>0: playmode=0
					x,y=bit.getpos(frame)
					off=x-mx,y-my
					if selectedbit.rot:
						dx=selectedbit.offset[0]+selectedbit.handle[0]-mx+off[0]
						dy=selectedbit.offset[1]+selectedbit.handle[1]-my+off[1]
						offrot=-math.atan2(dy,dx)-math.pi/2
					#pygame.mouse.set_pos((x-off[0],y-off[1])
					
		elif event.type == pygame.MOUSEBUTTONUP:
			if mousedown:
				print playmode
				print selectedbit.pos[-1]
			mousedown=0
			
		elif event.type == pygame.KEYDOWN:
			if event.key==32:
				playmode=1
				frame=-1
				longest=getbiggest(map(lambda x:len(x.pos),bits))
			elif event.key==27:
				for bit in bits:
					bit.pos=bit.pos[:1]
				print "RESET!"
				shotstaken=9
				frame=0
			elif event.key==115:
				filename='save.txt'
				print "saving to %s" % filename
				savescene(filename)
				print "saved"
			elif event.key==276:
				keydown=276
			elif event.key==275:
				keydown=275
			elif event.key==99:
				if selectedbit!=None:
					if frame==0: frame=1
					bit=selectedbit
					if len(bit.pos)>=frame:
						bit.pos=bit.pos[:frame]
			elif event.key==118:
				if selectedbit!=None:
					bit=selectedbit
					if len(bit.pos)<frame:
						for c in range(frame+1-len(bit.pos)):
							bit.pos.append(bit.pos[-1])
			elif event.key==112:
				for bit in bits:
					bit.pos=[bit.pos[-1]]
			elif event.key==105:
				shotstaken+=1
				pygame.image.save(screen,"screen%i.bmp" % shotstaken)
			elif event.key==117:
				if selectedbit!=None:
					i=bits.index(selectedbit)
					bits.pop(i)
					if i==0: i=1
					bits.insert(i-1,selectedbit)
			elif event.key==106:
				if selectedbit!=None:
					i=bits.index(selectedbit)
					bits.pop(i)
					if i==len(bits)-1: i=len(bits)-2
					bits.insert(i+1,selectedbit)
			elif event.key==114:
				if selectedbit!=None:
					selectedbit.pos=[selectedbit.pos[0]]
			elif event.key==116:
				if playmode==-1: playmode=0
				else: playmode=-1
				print ['normal','pause'][playmode]
			else:
				print event.key
		elif event.type == pygame.KEYUP:
			if event.key==keydown: keydown=0

	if keydown==276:
		frame-=1
		if frame<0: frame=getbiggest(map(lambda x:len(x.pos),bits))-1
	elif keydown==275:
		frame+=1
		if frame>=getbiggest(map(lambda x:len(x.pos),bits)): frame=0

	if playmode==1:
		frame=frame+1
		if frame%50==0: print frame/50
		if frame==longest: playmode=0
		
	if mousedown:
		if selectedbit.rot:
			x=selectedbit.offset[0]+selectedbit.handle[0]+selectedbit.centre[0]
			y=selectedbit.offset[1]+selectedbit.handle[1]+selectedbit.centre[1]
			dx=mx-x
			dy=my-y
			newpos=-math.atan2(dy,dx)+math.pi/2#+offrot
			newpos=int(newpos*180/math.pi)
		else:
			newpos=[mx+off[0],my+off[1]]
			if newpos[0]<0: newpos[0]=0
			if newpos[1]<0: newpos[1]=0
		if playmode==0:
			selectedbit.pos.append(newpos)
		elif playmode==-1:
			selectedbit.pos[-1]=newpos
		frame=len(selectedbit.pos)-1
	
	backbits=list(bits)
	backbits.reverse()
	for bit in backbits:
		bit.draw(frame)
	if mousedown:
		if selectedbit.rot:
			pygame.draw.circle(screen,black,(x,y),5)
			pygame.draw.circle(screen,black,selectedbit.getpos(frame),5)
			#pygame.draw.rect(screen,black,selectedbit.rotrect)
			
	pygame.display.flip()
	screen.fill(white)
