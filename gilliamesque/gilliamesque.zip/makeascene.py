import sys,os
inp="!"
folder=sys.argv[1]
f=open(folder+'.txt','w')
c=1
for filename in os.listdir(folder):
	f.write(folder+'\\'+filename+'\n')
	p=str(c*10)
	f.write('0'*(3-len(p))+p+'0'*(3-len(p))+p+'\n')
	f.write('0\n')
	c+=1
f.close()
print "done"