GROUPS OF LITTLE THINGS
or
BEFUNKED!

Instructions
------------

So these little things keep popping up all over the place. You have to sweep them up by holding down the left mouse button and making a sweeping motion, then pop the little things by tapping the left mouse button on one of them. Who knows why, but you get more points for popping lots of them together.
If you leave the little things to their own devices too long they might pop of their own accord, especially if they're in large groups. It's a mystery why, but you don't get any points when this happens.
Some of the little things are red and flashing. You can't pop them, but they might pop themselves and anything else near them, earning you no points.
Yet others are blue and flashing - they scoot about dragging the other things in their wake. You can't push them so your best bet is to try and pop a group when they're passing by it.
Finally, the last kind of thing sucks the other things towards it, popping them for no points when they get close. You'll just have to do your best until one of these things disappears after a short while.

After 60 seconds your time is up and you're given your score, for whatever reason. After that you can start the game again, if you like.