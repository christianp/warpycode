Trees!
by Warpy - mailto:webmaster@stormgames.co.uk

Installation:
Unzip all the files to the same directory, and run tree.bb

Playing:
Place some fruit, some butterflies and a couple of birds, then click on the Speed Up button to start the game.

Controls:
Left-click on an animal - feed it
Right-click on an animal - slap it (!)
cursor keys / move mouse to edge of screen - scroll

Menu Options:
Fruit - left-click picks up fruit, left-click again makes a new fruit. Right-click puts it back
Butterfly - same as fruit
Bird - same as fruit
Raindrop - same as fruit
Higher Res - Increases screen resolution
Lower Res - Decreases screen resolution
Raise Land - left-click picks up spade, left-click on ground raises ground. Right-click puts spade back
Lower Land - left-click picks up spade, left-click on ground lowers ground. Right-click puts spade back
Smooth Land - left-click picks up smoothing tool, left-click on ground smooths it out. Right-click puts tool back
Speed Up - left-click increases game speed
Slow Down - left-click decreases game speed